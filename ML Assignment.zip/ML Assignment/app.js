/**
 * Credit Card Fraud Detection — Client-Side Application Controller
 * Supports 4 Models: Random Forest, XGBoost, Logistic Regression, SVM
 */

// Benchmark sample transactions
const SAMPLE_LEGITIMATE = {
  transaction_amount: 45.00,
  average_transaction_amount: 50.00,
  merchant_category: "Grocery",
  payment_method: "Chip",
  device_type: "POS Terminal",
  customer_country: "India",
  customer_age: 42,
  account_age_days: 1500,
  transactions_last_24h: 1,
  failed_attempts_last_hour: 0,
  hour_of_day: 14,
  is_international: "0",
  is_weekend: "0",
};

const SAMPLE_FRAUD = {
  transaction_amount: 212.01,
  average_transaction_amount: 121.20,
  merchant_category: "Electronics",
  payment_method: "Online",
  device_type: "Desktop",
  customer_country: "USA",
  customer_age: 26,
  account_age_days: 321,
  transactions_last_24h: 5,
  failed_attempts_last_hour: 0,
  hour_of_day: 0,
  is_international: "1",
  is_weekend: "0",
};

if (typeof window !== "undefined") {
  window.SAMPLE_LEGITIMATE = SAMPLE_LEGITIMATE;
  window.SAMPLE_FRAUD = SAMPLE_FRAUD;
}
if (typeof global !== "undefined") {
  global.SAMPLE_LEGITIMATE = SAMPLE_LEGITIMATE;
  global.SAMPLE_FRAUD = SAMPLE_FRAUD;
}

// UI Elements mapping
const DOM = typeof document !== "undefined" ? {
  form: document.getElementById("predictionForm"),
  btnAnalyze: document.getElementById("btnAnalyze"),
  btnClear: document.getElementById("btnClear"),
  btnFillLegit: document.getElementById("btnFillLegit"),
  btnFillFraud: document.getElementById("btnFillFraud"),
  btnRandomize: document.getElementById("btnRandomize"),
  alertBanner: document.getElementById("alertBanner"),

  // Section 2: Selected Model Result
  resultSection: document.getElementById("predictionResultSection"),
  resultBanner: document.getElementById("resultBanner"),
  resultBadge: document.getElementById("resultBadge"),
  resultSubtitle: document.getElementById("resultSubtitle"),
  resultModelName: document.getElementById("resultModelName"),
  resultDecisionScore: document.getElementById("resultDecisionScore"),
  resultProbability: document.getElementById("resultProbability"),
  resultExplanation: document.getElementById("resultExplanation"),

  // Section 3: Multi-Model Comparison (At the Bottom)
  comparisonSection: document.getElementById("modelComparisonSection"),
  consensusBanner: document.getElementById("consensusBanner"),
  consensusText: document.getElementById("consensusText"),
  consensusPill: document.getElementById("consensusPill"),
  liveCompareGrid: document.getElementById("liveCompareGrid"),
  benchmarkTableBody: document.getElementById("benchmarkTableBody"),
} : {};

let lastInferenceResults = null;

/**
 * Transforms raw user inputs into the 36-dimensional scaled numerical + one-hot vector.
 */
function preprocessInput(inputData) {
  if (typeof MODEL_DATA === "undefined" || !MODEL_DATA.preprocessor) {
    throw new Error("Model parameters (model_data.js) are not loaded.");
  }

  const prep = MODEL_DATA.preprocessor;

  // 1. Feature Engineering
  const txn_amt = parseFloat(inputData.transaction_amount) || prep.num_medians[0];
  const avg_amt = parseFloat(inputData.average_transaction_amount) || 1e-5;
  const ratio = txn_amt / avg_amt;
  const hour = parseInt(inputData.hour_of_day, 10) || 12;
  const is_night = (hour >= 0 && hour <= 6) ? 1 : 0;
  const failed = parseInt(inputData.failed_attempts_last_hour, 10) || 0;
  const has_failed = failed > 0 ? 1 : 0;

  // 2. Numerical Features
  const raw_num = [
    txn_amt,
    parseFloat(inputData.customer_age) || prep.num_medians[1],
    parseFloat(inputData.account_age_days) || prep.num_medians[2],
    parseFloat(inputData.transactions_last_24h) || 0,
    failed,
    parseFloat(inputData.is_international) || 0,
    parseFloat(inputData.is_weekend) || 0,
    hour,
    avg_amt,
    ratio,
    is_night,
    has_failed,
  ];

  const x_num = raw_num.map((val, idx) => (val - prep.scaler_mean[idx]) / prep.scaler_scale[idx]);

  // 3. Categorical Features
  const raw_cat = [
    inputData.merchant_category,
    inputData.payment_method,
    inputData.device_type,
    inputData.customer_country,
  ];

  const x_cat = [];
  prep.cat_categories.forEach((categories, cIdx) => {
    const val = raw_cat[cIdx];
    categories.forEach(cat => {
      x_cat.push(val === cat ? 1.0 : 0.0);
    });
  });

  const x = x_num.concat(x_cat);

  const isInternational = inputData.is_international === "1" || inputData.is_international === 1;
  const isWeekend = inputData.is_weekend === "1" || inputData.is_weekend === 1;

  const metadata = {
    txn_amt,
    avg_amt,
    ratio,
    hour,
    is_night,
    failed_attempts: failed,
    has_failed,
    velocity: parseInt(inputData.transactions_last_24h, 10) || 0,
    account_age: parseInt(inputData.account_age_days, 10) || 0,
    customer_age: parseInt(inputData.customer_age, 10) || 0,
    is_international: isInternational,
    is_weekend: isWeekend,
    merchant_category: inputData.merchant_category || "General",
    payment_method: inputData.payment_method || "Online",
    device_type: inputData.device_type || "Mobile",
    customer_country: inputData.customer_country || "USA",
  };

  return { x, metadata };
}

/**
 * 1. Logistic Regression
 */
function predictLogisticRegression(x, meta) {
  const lr = MODEL_DATA.logistic_regression;
  let z = lr.intercept;
  for (let i = 0; i < x.length; i++) {
    z += lr.coef[i] * x[i];
  }
  const prob = 1.0 / (1.0 + Math.exp(-z));
  const isFraud = prob >= 0.5 ? 1 : 0;

  return {
    key: "logistic_regression",
    name: "Logistic Regression",
    badge: "Baseline",
    is_fraud: isFraud,
    label: isFraud ? "Fraudulent" : "Legitimate",
    decision_score: z,
    probability: prob,
    ...meta,
  };
}

/**
 * 2. Random Forest
 */
function predictRandomForest(x, meta) {
  const rf = MODEL_DATA.random_forest;

  function evalRFTree(nodes, idx) {
    const n = nodes[idx];
    if (n.l === -1) return n.p;
    const nextIdx = x[n.f] <= n.th ? n.l : n.r;
    return evalRFTree(nodes, nextIdx);
  }

  let sumProb = 0;
  for (let i = 0; i < rf.trees.length; i++) {
    sumProb += evalRFTree(rf.trees[i], 0);
  }
  const prob = sumProb / rf.trees.length;
  const isFraud = prob >= 0.5 ? 1 : 0;
  const score = Math.log((prob + 1e-6) / (1.0 - prob + 1e-6));

  return {
    key: "random_forest",
    name: "Random Forest",
    badge: "Ensemble",
    is_fraud: isFraud,
    label: isFraud ? "Fraudulent" : "Legitimate",
    decision_score: score,
    probability: prob,
    ...meta,
  };
}

/**
 * 3. XGBoost
 */
function predictXGBoost(x, meta) {
  const xgbData = MODEL_DATA.xgboost;

  function evalXGBNode(n) {
    if ("leaf" in n) return n.leaf;
    const feat = parseInt(n.split.substring(1), 10);
    const target = Math.fround(x[feat]) < Math.fround(n.split_condition) ? n.yes : n.no;
    const child = n.children.find(c => c.nodeid === target);
    return child ? evalXGBNode(child) : 0;
  }

  let sumLeaves = 0;
  for (let i = 0; i < xgbData.trees.length; i++) {
    sumLeaves += evalXGBNode(xgbData.trees[i]);
  }
  const prob = 1.0 / (1.0 + Math.exp(-sumLeaves));
  const isFraud = prob >= 0.5 ? 1 : 0;

  return {
    key: "xgboost",
    name: "XGBoost",
    badge: "Boosted Trees",
    is_fraud: isFraud,
    label: isFraud ? "Fraudulent" : "Legitimate",
    decision_score: sumLeaves,
    probability: prob,
    ...meta,
  };
}

/**
 * 4. Support Vector Machine
 */
function predictSVM(x, meta) {
  const m = MODEL_DATA;
  const gamma = m.svm.gamma;
  let decisionScore = m.svm.intercept;
  const n_sv = m.svm.support_vectors.length;

  for (let i = 0; i < n_sv; i++) {
    const sv = m.svm.support_vectors[i];
    let distSq = 0;
    for (let j = 0; j < 36; j++) {
      const diff = x[j] - sv[j];
      distSq += diff * diff;
    }
    decisionScore += m.svm.dual_coef[i] * Math.exp(-gamma * distSq);
  }

  const a = m.svm.calibrator.a;
  const b = m.svm.calibrator.b;
  const calibratedProb = 1.0 / (1.0 + Math.exp(a * decisionScore + b));
  const isFraud = decisionScore >= 0 ? 1 : 0;

  return {
    key: "svm",
    name: "Support Vector Machine",
    badge: "RBF Kernel",
    is_fraud: isFraud,
    label: isFraud ? "Fraudulent" : "Legitimate",
    decision_score: decisionScore,
    probability: calibratedProb,
    ...meta,
  };
}

/**
 * Evaluates all 4 models simultaneously.
 */
function predictAllModels(inputData) {
  const { x, metadata } = preprocessInput(inputData);

  const lr = predictLogisticRegression(x, metadata);
  const rf = predictRandomForest(x, metadata);
  const xgb = predictXGBoost(x, metadata);
  const svm = predictSVM(x, metadata);

  const allModels = {
    random_forest: rf,
    xgboost: xgb,
    logistic_regression: lr,
    svm: svm,
  };

  const fraudVotes = (rf.is_fraud ? 1 : 0) + (xgb.is_fraud ? 1 : 0) + (lr.is_fraud ? 1 : 0) + (svm.is_fraud ? 1 : 0);
  const legitVotes = 4 - fraudVotes;

  return {
    all: allModels,
    fraudVotes,
    legitVotes,
    metadata,
  };
}

/**
 * Generates concise, direct bullet factors without lengthy theoretical text.
 */
function generateCompactRiskAnalysis(result) {
  const factors = [];

  // Spending ratio
  if (result.ratio >= 2.0) {
    factors.push({
      type: "risk",
      text: `Amount ($${result.txn_amt.toFixed(2)}) is ${result.ratio.toFixed(1)}x higher than average ($${result.avg_amt.toFixed(2)})`
    });
  } else if (result.ratio <= 0.25 && result.avg_amt >= 100) {
    factors.push({
      type: "risk",
      text: `Unusually small probing charge ($${result.txn_amt.toFixed(2)}) compared to average ($${result.avg_amt.toFixed(2)})`
    });
  } else {
    factors.push({
      type: "safe",
      text: `Amount ($${result.txn_amt.toFixed(2)}) conforms to normal spending baseline ($${result.avg_amt.toFixed(2)})`
    });
  }

  // Time of day
  if (result.is_night) {
    factors.push({
      type: "risk",
      text: `Nocturnal transaction initiated at ${result.hour}:00 (12 AM - 6 AM)`
    });
  } else {
    factors.push({
      type: "safe",
      text: `Regular daytime transaction hour (${result.hour}:00)`
    });
  }

  // Failed attempts
  if (result.failed_attempts >= 1) {
    factors.push({
      type: "risk",
      text: `${result.failed_attempts} failed PIN/authentication attempt(s) in last hour`
    });
  } else {
    factors.push({
      type: "safe",
      text: `Zero failed authentication attempts in last hour`
    });
  }

  // Velocity
  if (result.velocity >= 4) {
    factors.push({
      type: "risk",
      text: `Elevated daily frequency: ${result.velocity} transactions in 24 hours`
    });
  } else {
    factors.push({
      type: "safe",
      text: `Normal velocity: ${result.velocity} transaction(s) in 24 hours`
    });
  }

  // International
  if (result.is_international) {
    factors.push({
      type: "risk",
      text: `Cross-border transaction outside registered country (${result.customer_country})`
    });
  } else {
    factors.push({
      type: "safe",
      text: `Domestic transaction in ${result.customer_country}`
    });
  }

  return factors;
}

/**
 * Gets currently selected model key from the radio cards.
 */
function getSelectedModelKey() {
  const checked = document.querySelector('input[name="modelChoice"]:checked');
  return checked ? checked.value : "random_forest";
}

/**
 * Renders primary prediction result and the compared results at the bottom.
 */
function displayResult(allPredictions, selectedKey) {
  lastInferenceResults = allPredictions;
  const activeResult = allPredictions.all[selectedKey];
  const isFraud = activeResult.is_fraud === 1;
  const factors = generateCompactRiskAnalysis(activeResult);

  // Unhide both sections
  DOM.resultSection.classList.remove("hidden");
  DOM.comparisonSection.classList.remove("hidden");

  // ==========================================
  // 1. UPDATE SECTION 2: PRIMARY RESULT
  // ==========================================
  DOM.resultModelName.textContent = activeResult.name;
  DOM.resultBanner.className = `result-banner ${isFraud ? "result-fraud" : "result-legit"}`;
  DOM.resultBadge.textContent = isFraud ? "FRAUD DETECTED" : "LEGITIMATE";
  DOM.resultSubtitle.textContent = isFraud
    ? `${activeResult.name} flagged this transaction as high risk.`
    : `${activeResult.name} verified this transaction as normal.`;

  const sign = activeResult.decision_score > 0 ? "+" : "";
  DOM.resultDecisionScore.textContent = `${sign}${activeResult.decision_score.toFixed(3)}`;
  DOM.resultProbability.textContent = `${(activeResult.probability * 100).toFixed(1)}%`;

  // Render clean compact factors list
  let html = `
    <div class="factors-section-title">
      <span>Key Transaction Factors:</span>
    </div>
    <div class="compact-factors-list">
  `;

  factors.forEach(f => {
    const isR = f.type === "risk";
    html += `
      <div class="compact-factor-item ${isR ? 'item-risk' : 'item-safe'}">
        <span class="factor-tag ${isR ? 'tag-risk' : 'tag-safe'}">${isR ? 'Risk Signal' : 'Normal'}</span>
        <span class="factor-text">${f.text}</span>
      </div>
    `;
  });

  html += `</div>`;
  DOM.resultExplanation.innerHTML = html;

  // ==========================================
  // 2. UPDATE SECTION 3: COMPARED RESULT (AT BOTTOM)
  // ==========================================
  renderComparedResults(allPredictions, selectedKey);

  // Smooth scroll
  DOM.resultSection.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

/**
 * Renders the multi-model comparison cards, consensus banner, and benchmark table.
 */
function renderComparedResults(allPredictions, selectedKey) {
  const models = allPredictions.all;
  const fraudVotes = allPredictions.fraudVotes;
  const legitVotes = allPredictions.legitVotes;

  // 1. Consensus Banner
  if (fraudVotes === 4) {
    DOM.consensusBanner.className = "compare-consensus-banner fraud";
    DOM.consensusText.textContent = "All 4 models classified this transaction as Fraud";
    DOM.consensusPill.textContent = "4 / 4 Fraud";
  } else if (legitVotes === 4) {
    DOM.consensusBanner.className = "compare-consensus-banner legit";
    DOM.consensusText.textContent = "All 4 models classified this transaction as Legitimate";
    DOM.consensusPill.textContent = "4 / 4 Legit";
  } else if (fraudVotes >= 2) {
    DOM.consensusBanner.className = "compare-consensus-banner split";
    DOM.consensusText.textContent = `Split Decision: ${fraudVotes} models vote Fraud, ${legitVotes} vote Legitimate`;
    DOM.consensusPill.textContent = `${fraudVotes} Fraud / ${legitVotes} Legit`;
  } else {
    DOM.consensusBanner.className = "compare-consensus-banner legit";
    DOM.consensusText.textContent = `Majority Decision: ${legitVotes} of 4 models vote Legitimate`;
    DOM.consensusPill.textContent = `${legitVotes} Legit / ${fraudVotes} Fraud`;
  }

  // 2. Live Multi-Model Comparison Cards
  const modelOrder = ["random_forest", "xgboost", "logistic_regression", "svm"];
  let liveHtml = "";

  modelOrder.forEach(key => {
    const m = models[key];
    const isAct = key === selectedKey;
    const isMFrd = m.is_fraud === 1;
    const probPct = (m.probability * 100).toFixed(1);

    liveHtml += `
      <div class="live-model-card ${isAct ? 'is-active-model' : ''} ${isMFrd ? 'is-fraud' : 'is-legit'}">
        <div class="live-model-header">
          <div>
            <div class="live-model-title">${m.name}</div>
            <span class="model-badge ${key === 'random_forest' ? 'badge-rf' : (key === 'xgboost' ? 'badge-xgb' : (key === 'logistic_regression' ? 'badge-lr' : 'badge-svm'))}">
              ${m.badge}
            </span>
          </div>
          ${isAct ? '<span class="active-model-indicator">Active</span>' : ''}
        </div>

        <div class="live-model-prediction">
          <span class="prediction-pill ${isMFrd ? 'fraud' : 'legit'}">
            ${isMFrd ? 'Fraud' : 'Legitimate'}
          </span>
        </div>

        <div class="live-model-prob">
          <div class="prob-label-row">
            <span>Fraud Risk:</span>
            <span class="prob-val">${probPct}%</span>
          </div>
          <div class="prob-bar-container">
            <div class="prob-bar-fill ${isMFrd ? 'fraud' : 'legit'}" style="width: ${Math.max(4, Math.min(100, probPct))}%"></div>
          </div>
        </div>

        <div class="live-model-margin">
          Score: <code>${m.decision_score > 0 ? '+' : ''}${m.decision_score.toFixed(3)}</code>
        </div>
      </div>
    `;
  });

  DOM.liveCompareGrid.innerHTML = liveHtml;

  // 3. Holdout Test Set Benchmark Matrix Table
  if (MODEL_DATA.metrics && MODEL_DATA.metrics.comparison_table) {
    const tableRows = MODEL_DATA.metrics.comparison_table;
    let tableHtml = "";

    const modelNameMap = {
      logistic_regression: "Logistic Regression",
      random_forest: "Random Forest",
      xgboost: "XGBoost",
      svm: "SVM",
    };

    tableRows.forEach(row => {
      const lrVal = (row.logistic_regression * 100).toFixed(1) + "%";
      const rfVal = (row.random_forest * 100).toFixed(1) + "%";
      const xgbVal = (row.xgboost * 100).toFixed(1) + "%";
      const svmVal = (row.svm * 100).toFixed(1) + "%";
      const winKey = row.winner;

      tableHtml += `
        <tr>
          <td class="metric-name">${row.display_name}</td>
          <td class="${winKey === 'logistic_regression' ? 'val-winner' : ''}">${lrVal}</td>
          <td class="${winKey === 'random_forest' ? 'val-winner' : ''}">${rfVal}</td>
          <td class="${winKey === 'xgboost' ? 'val-winner' : ''}">${xgbVal}</td>
          <td class="${winKey === 'svm' ? 'val-winner' : ''}">${svmVal}</td>
          <td><span class="badge-winner">${modelNameMap[winKey] || winKey}</span></td>
        </tr>
      `;
    });

    // Confusion Matrix breakdown rows
    const m = MODEL_DATA.metrics.models;
    if (m) {
      tableHtml += `
        <tr>
          <td class="metric-name">Missed Frauds (FN)</td>
          <td class="val-winner">${m.logistic_regression.confusion_matrix.fn} (Lowest)</td>
          <td>${m.random_forest.confusion_matrix.fn}</td>
          <td>${m.xgboost.confusion_matrix.fn}</td>
          <td>${m.svm.confusion_matrix.fn}</td>
          <td><span class="badge-winner">Logistic Regression</span></td>
        </tr>
        <tr>
          <td class="metric-name">False Alarms (FP)</td>
          <td>${m.logistic_regression.confusion_matrix.fp}</td>
          <td>${m.random_forest.confusion_matrix.fp}</td>
          <td class="val-winner">${m.xgboost.confusion_matrix.fp} (Lowest)</td>
          <td>${m.svm.confusion_matrix.fp}</td>
          <td><span class="badge-winner">XGBoost</span></td>
        </tr>
      `;
    }

    DOM.benchmarkTableBody.innerHTML = tableHtml;
  }
}

/**
 * Extracts form field values into an object.
 */
function getFormData() {
  const data = {};
  const elements = DOM.form.elements;
  for (let i = 0; i < elements.length; i++) {
    const el = elements[i];
    if (el.name && el.name !== "modelChoice") {
      if (el.required && (!el.value || el.value.trim() === "")) {
        el.focus();
        throw new Error(`Please provide a value for '${el.previousElementSibling ? el.previousElementSibling.innerText : el.name}'.`);
      }
      data[el.name] = el.value.trim();
    }
  }
  return data;
}

/**
 * Fills the prediction form with provided object data.
 */
function fillForm(data) {
  Object.keys(data).forEach(key => {
    const field = DOM.form.elements[key];
    if (field) {
      field.value = data[key];
    }
  });
}

/**
 * Displays notification alerts.
 */
function showAlert(message, type = "info") {
  DOM.alertBanner.className = `alert-banner ${type}`;
  DOM.alertBanner.textContent = message;
  DOM.alertBanner.classList.remove("hidden");
}

function hideAlert() {
  DOM.alertBanner.classList.add("hidden");
}

/**
 * Randomizes inputs using authentic holdout samples from the dataset.
 */
function handleRandomize() {
  hideAlert();
  let sample;

  if (typeof MODEL_DATA !== "undefined" && MODEL_DATA.sample_pool && MODEL_DATA.sample_pool.length > 0) {
    const randIdx = Math.floor(Math.random() * MODEL_DATA.sample_pool.length);
    sample = MODEL_DATA.sample_pool[randIdx];
  } else {
    sample = SAMPLE_LEGITIMATE;
  }

  fillForm(sample);
  showAlert("Sample transaction loaded. Click 'Analyze Transaction' to evaluate.", "info");

  if (DOM.form) {
    DOM.form.style.transition = "transform 0.15s ease";
    DOM.form.style.transform = "scale(0.998)";
    setTimeout(() => {
      DOM.form.style.transform = "scale(1)";
    }, 150);
  }
}

// Global exports
if (typeof window !== "undefined") {
  window.preprocessInput = preprocessInput;
  window.predictLogisticRegression = predictLogisticRegression;
  window.predictRandomForest = predictRandomForest;
  window.predictXGBoost = predictXGBoost;
  window.predictSVM = predictSVM;
  window.predictAllModels = predictAllModels;
}

// Event Listeners initialization
if (typeof document !== "undefined") {
  document.addEventListener("DOMContentLoaded", () => {

    // Model Selector Radio Cards Interaction
    const modelCards = document.querySelectorAll(".model-card");
    modelCards.forEach(card => {
      card.addEventListener("click", () => {
        modelCards.forEach(c => c.classList.remove("active"));
        card.classList.add("active");
        const radio = card.querySelector('input[type="radio"]');
        if (radio) {
          radio.checked = true;
        }

        // If results are already showing, immediately switch active model view
        if (lastInferenceResults) {
          displayResult(lastInferenceResults, radio.value);
        }
      });
    });

    // Quick-fill buttons
    if (DOM.btnFillLegit) {
      DOM.btnFillLegit.addEventListener("click", () => {
        fillForm(SAMPLE_LEGITIMATE);
        hideAlert();
      });
    }

    if (DOM.btnFillFraud) {
      DOM.btnFillFraud.addEventListener("click", () => {
        fillForm(SAMPLE_FRAUD);
        hideAlert();
      });
    }

    // Randomize button
    if (DOM.btnRandomize) {
      DOM.btnRandomize.addEventListener("click", handleRandomize);
    }

    // Clear button
    if (DOM.btnClear) {
      DOM.btnClear.addEventListener("click", () => {
        DOM.form.reset();
        DOM.resultSection.classList.add("hidden");
        DOM.comparisonSection.classList.add("hidden");
        lastInferenceResults = null;
        hideAlert();
      });
    }

    // Form submission & in-browser multi-model inference
    if (DOM.form) {
      DOM.form.addEventListener("submit", (e) => {
        e.preventDefault();
        hideAlert();

        try {
          const formData = getFormData();
          const selectedModelKey = getSelectedModelKey();
          const allPredictions = predictAllModels(formData);
          displayResult(allPredictions, selectedModelKey);
        } catch (err) {
          showAlert(err.message, "error");
        }
      });
    }
  });
}
