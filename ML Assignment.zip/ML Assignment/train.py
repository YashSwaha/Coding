"""
Credit Card Fraud Detection — Multi-Model Training Script
Trains 4 Machine Learning Models:
  1. Logistic Regression (Linear Baseline)
  2. Random Forest (Ensemble Bagging)
  3. XGBoost (Gradient Boosting Decision Trees)
  4. Support Vector Machine (RBF Kernel Maximum Margin)

Saves all serialized models and metrics into models/ and exports client-side model_data.js.
"""
import os
import json
import joblib
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, precision_score,
    recall_score, f1_score, roc_auc_score, average_precision_score,
    confusion_matrix, classification_report
)
import xgboost as xgb

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "test_credit_card.csv")
MODELS_DIR = os.path.join(BASE_DIR, "models")
MODEL_DATA_JS_PATH = os.path.join(BASE_DIR, "model_data.js")

RANDOM_SEED = 42
TEST_SIZE = 0.2
TARGET_COL = "is_fraud"

NUMERICAL_FEATURES = [
    "transaction_amount",
    "customer_age",
    "account_age_days",
    "transactions_last_24h",
    "failed_attempts_last_hour",
    "is_international",
    "is_weekend",
    "hour_of_day",
    "average_transaction_amount",
]

CATEGORICAL_FEATURES = [
    "merchant_category",
    "payment_method",
    "device_type",
    "customer_country",
]

ENGINEERED_FEATURES = [
    "amount_to_avg_ratio",
    "is_night_transaction",
    "has_failed_attempts",
]

ALL_NUMERICAL_FEATURES = NUMERICAL_FEATURES + ENGINEERED_FEATURES


def add_engineered_features(df: pd.DataFrame) -> pd.DataFrame:
    """Adds behavioral fraud risk features."""
    df_feat = df.copy()
    txn_amt = pd.to_numeric(df_feat["transaction_amount"], errors="coerce")
    avg_amt = pd.to_numeric(df_feat["average_transaction_amount"], errors="coerce").replace(0, 1e-5)
    df_feat["amount_to_avg_ratio"] = txn_amt / avg_amt

    hour = pd.to_numeric(df_feat["hour_of_day"], errors="coerce").fillna(12)
    df_feat["is_night_transaction"] = ((hour >= 0) & (hour <= 6)).astype(int)

    failed = pd.to_numeric(df_feat["failed_attempts_last_hour"], errors="coerce").fillna(0)
    df_feat["has_failed_attempts"] = (failed > 0).astype(int)
    return df_feat


def evaluate(model, X_test, y_test, name="Model"):
    """Calculates comprehensive classification metrics."""
    y_pred = model.predict(X_test)
    if hasattr(model, "predict_proba"):
        y_scores = model.predict_proba(X_test)[:, 1]
    elif hasattr(model, "decision_function"):
        y_scores = model.decision_function(X_test)
    else:
        y_scores = y_pred

    cm = confusion_matrix(y_test, y_pred).tolist()
    return {
        "model_name": name,
        "accuracy": round(float(accuracy_score(y_test, y_pred)), 4),
        "balanced_accuracy": round(float(balanced_accuracy_score(y_test, y_pred)), 4),
        "precision": round(float(precision_score(y_test, y_pred, zero_division=0)), 4),
        "recall": round(float(recall_score(y_test, y_pred, zero_division=0)), 4),
        "f1": round(float(f1_score(y_test, y_pred, zero_division=0)), 4),
        "roc_auc": round(float(roc_auc_score(y_test, y_scores)), 4),
        "pr_auc": round(float(average_precision_score(y_test, y_scores)), 4),
        "confusion_matrix": {
            "matrix": cm,
            "tn": int(cm[0][0]),
            "fp": int(cm[0][1]),
            "fn": int(cm[1][0]),
            "tp": int(cm[1][1]),
        },
        "classification_report": classification_report(y_test, y_pred, output_dict=True, zero_division=0),
    }


def export_rf_trees(rf_model):
    """Exports Random Forest decision trees into compact JSON-compatible list."""
    trees = []
    for dt in rf_model.estimators_:
        tr = dt.tree_
        nodes = []
        for i in range(tr.node_count):
            counts = tr.value[i][0]
            total = counts.sum()
            prob = float(counts[1] / total) if total > 0 else 0.0
            nodes.append({
                "f": int(tr.feature[i]),
                "th": round(float(tr.threshold[i]), 5),
                "l": int(tr.children_left[i]),
                "r": int(tr.children_right[i]),
                "p": round(prob, 5),
            })
        trees.append(nodes)
    return trees


def export_xgb_trees(xgb_model):
    """Exports XGBoost tree dumps into clean JSON objects."""
    booster = xgb_model.get_booster()
    dump = booster.get_dump(dump_format="json")
    trees = [json.loads(t) for t in dump]
    return trees


def train_and_export():
    print("=" * 70)
    print("Training Multi-Model Credit Card Fraud Detection Suite")
    print("Models: Logistic Regression, Random Forest, XGBoost, Support Vector Machine")
    print("=" * 70)
    os.makedirs(MODELS_DIR, exist_ok=True)

    # 1. Load data
    print(f"[1/7] Loading dataset from {DATA_PATH}...")
    df_raw = pd.read_csv(DATA_PATH)
    total_raw = len(df_raw)
    df_clean = df_raw.drop_duplicates().reset_index(drop=True)
    print(f"Loaded {total_raw} rows, removed {total_raw - len(df_clean)} duplicates. Cleaned rows: {len(df_clean)}")

    # Summary statistics
    fraud_cnt = int((df_clean[TARGET_COL] == 1).sum())
    legit_cnt = int((df_clean[TARGET_COL] == 0).sum())
    summary = {
        "dataset_name": "test_credit_card.csv",
        "total_records": total_raw,
        "unique_records": len(df_clean),
        "total_features": len(df_clean.columns),
        "legitimate_count": legit_cnt,
        "fraud_count": fraud_cnt,
        "legitimate_percentage": round((legit_cnt / len(df_clean)) * 100, 2),
        "fraud_percentage": round((fraud_cnt / len(df_clean)) * 100, 2),
        "duplicate_count": total_raw - len(df_clean),
        "missing_values": {c: int(df_clean[c].isnull().sum()) for c in df_clean.columns if df_clean[c].isnull().sum() > 0},
    }
    with open(os.path.join(MODELS_DIR, "dataset_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    # 2. Preprocessing & Feature Engineering
    print("[2/7] Engineering behavioral features and building column transformers...")
    y = df_clean[TARGET_COL].astype(int)
    X_raw = df_clean[NUMERICAL_FEATURES + CATEGORICAL_FEATURES].copy()
    X_feat = add_engineered_features(X_raw)

    X_train_raw, X_test_raw, y_train, y_test = train_test_split(
        X_feat, y, test_size=TEST_SIZE, random_state=RANDOM_SEED, stratify=y
    )

    num_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    cat_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])
    col_transformer = ColumnTransformer(
        transformers=[
            ("num", num_pipeline, ALL_NUMERICAL_FEATURES),
            ("cat", cat_pipeline, CATEGORICAL_FEATURES),
        ],
        remainder="drop",
    )

    X_train = col_transformer.fit_transform(X_train_raw)
    X_test = col_transformer.transform(X_test_raw)
    print(f"Transformed feature space shape: {X_train.shape} (12 numerical + 24 categorical dummy features)")

    # 3. Train Model 1: Logistic Regression
    print("[3/7] Training Model 1: Logistic Regression (Balanced Baseline)...")
    lr_model = LogisticRegression(class_weight="balanced", random_state=RANDOM_SEED, max_iter=1000)
    lr_model.fit(X_train, y_train)
    metrics_lr = evaluate(lr_model, X_test, y_test, "Logistic Regression")

    # 4. Train Model 2: Random Forest
    print("[4/7] Training Model 2: Random Forest Classifier (Bagging Ensemble)...")
    rf_model = RandomForestClassifier(
        n_estimators=40,
        max_depth=6,
        class_weight="balanced",
        random_state=RANDOM_SEED,
        n_jobs=-1
    )
    rf_model.fit(X_train, y_train)
    metrics_rf = evaluate(rf_model, X_test, y_test, "Random Forest")

    # 5. Train Model 3: XGBoost
    print("[5/7] Training Model 3: XGBoost Classifier (Gradient Boosting)...")
    neg_count = int((y_train == 0).sum())
    pos_count = int((y_train == 1).sum())
    scale_pos = neg_count / pos_count
    xgb_model = xgb.XGBClassifier(
        n_estimators=40,
        max_depth=4,
        learning_rate=0.1,
        scale_pos_weight=scale_pos,
        random_state=RANDOM_SEED,
        eval_metric="logloss",
        base_score=0.5
    )
    xgb_model.fit(X_train, y_train)
    metrics_xgb = evaluate(xgb_model, X_test, y_test, "XGBoost")

    # 6. Train Model 4: Support Vector Machine (RBF Kernel)
    print("[6/7] Training Model 4: Support Vector Machine (RBF Kernel & Platt Calibration)...")
    svm_model = SVC(kernel="rbf", C=0.5, gamma=0.1, class_weight="balanced", random_state=RANDOM_SEED)
    svm_model.fit(X_train, y_train)
    metrics_svm = evaluate(svm_model, X_test, y_test, "Support Vector Machine (SVM)")

    calibrated_svm = CalibratedClassifierCV(estimator=svm_model, method="sigmoid", cv=3)
    calibrated_svm.fit(X_train, y_train)

    # Feature Importance Extraction
    cat_encoder = col_transformer.named_transformers_["cat"].named_steps["encoder"]
    encoded_cat_names = list(cat_encoder.get_feature_names_out(CATEGORICAL_FEATURES))
    feature_names = ALL_NUMERICAL_FEATURES + encoded_cat_names

    rf_importances = [
        {"feature": feature_names[i], "importance": round(float(rf_model.feature_importances_[i]), 5)}
        for i in np.argsort(rf_model.feature_importances_)[::-1][:10]
    ]
    xgb_importances = [
        {"feature": feature_names[i], "importance": round(float(xgb_model.feature_importances_[i]), 5)}
        for i in np.argsort(xgb_model.feature_importances_)[::-1][:10]
    ]

    # Model Comparison Table
    models_list = [
        ("logistic_regression", metrics_lr),
        ("random_forest", metrics_rf),
        ("xgboost", metrics_xgb),
        ("svm", metrics_svm),
    ]

    metric_names = [
        ("accuracy", "Accuracy"),
        ("balanced_accuracy", "Balanced Accuracy"),
        ("precision", "Precision"),
        ("recall", "Recall"),
        ("f1", "F1-Score"),
        ("roc_auc", "ROC-AUC"),
        ("pr_auc", "PR-AUC"),
    ]

    comparison_table = []
    for metric_key, display_name in metric_names:
        row = {"metric": metric_key, "display_name": display_name}
        vals = {}
        for key, m in models_list:
            vals[key] = m[metric_key]
            row[key] = m[metric_key]
        best_model = max(vals, key=vals.get)
        row["winner"] = best_model
        comparison_table.append(row)

    metrics_full = {
        "models": {
            "logistic_regression": metrics_lr,
            "random_forest": metrics_rf,
            "xgboost": metrics_xgb,
            "svm": metrics_svm,
        },
        "comparison_table": comparison_table,
        "feature_importances": {
            "random_forest": rf_importances,
            "xgboost": xgb_importances,
        },
        "best_hyperparameters": {
            "logistic_regression": {"class_weight": "balanced", "max_iter": 1000},
            "random_forest": {"n_estimators": 40, "max_depth": 6, "class_weight": "balanced"},
            "xgboost": {"n_estimators": 40, "max_depth": 4, "learning_rate": 0.1, "scale_pos_weight": round(scale_pos, 2)},
            "svm": {"C": 0.5, "gamma": 0.1, "kernel": "rbf", "class_weight": "balanced"},
        },
    }

    with open(os.path.join(MODELS_DIR, "metrics.json"), "w") as f:
        json.dump(metrics_full, f, indent=2)

    # Save joblib models
    print("Saving serialized model artifacts to models/...")
    joblib.dump(lr_model, os.path.join(MODELS_DIR, "lr_model.joblib"))
    joblib.dump(rf_model, os.path.join(MODELS_DIR, "rf_model.joblib"))
    joblib.dump(xgb_model, os.path.join(MODELS_DIR, "xgb_model.joblib"))
    joblib.dump({"svm_model": svm_model, "calibrated_model": calibrated_svm}, os.path.join(MODELS_DIR, "svm_model.joblib"))
    joblib.dump(col_transformer, os.path.join(MODELS_DIR, "preprocessing.joblib"))

    # 7. Export Client-Side model_data.js
    print("[7/7] Generating self-contained browser bundle model_data.js...")
    num_step = col_transformer.named_transformers_["num"]
    cat_step = col_transformer.named_transformers_["cat"]
    num_imputer = num_step.named_steps["imputer"]
    scaler = num_step.named_steps["scaler"]
    encoder = cat_step.named_steps["encoder"]

    calibrators = [(float(c.calibrators[0].a_), float(c.calibrators[0].b_)) for c in calibrated_svm.calibrated_classifiers_]
    avg_a = float(np.mean([c[0] for c in calibrators]))
    avg_b = float(np.mean([c[1] for c in calibrators]))

    # Export sample pool for randomized testing (15 legit, 15 fraud)
    sample_rows = []
    legit_samples = df_clean[df_clean[TARGET_COL] == 0].sample(n=15, random_state=42)
    fraud_samples = df_clean[df_clean[TARGET_COL] == 1].sample(n=15, random_state=42)
    combined_samples = pd.concat([legit_samples, fraud_samples]).sample(frac=1.0, random_state=42)

    for _, row in combined_samples.iterrows():
        sample_rows.append({
            "transaction_amount": round(float(row["transaction_amount"]) if pd.notnull(row["transaction_amount"]) else 85.77, 2),
            "average_transaction_amount": round(float(row["average_transaction_amount"]), 2),
            "merchant_category": str(row["merchant_category"]),
            "payment_method": str(row["payment_method"]),
            "device_type": str(row["device_type"]) if pd.notnull(row["device_type"]) else "Mobile",
            "customer_country": str(row["customer_country"]),
            "customer_age": int(row["customer_age"]),
            "account_age_days": int(row["account_age_days"]),
            "transactions_last_24h": int(row["transactions_last_24h"]),
            "failed_attempts_last_hour": int(row["failed_attempts_last_hour"]),
            "hour_of_day": int(row["hour_of_day"]),
            "is_international": str(int(row["is_international"])),
            "is_weekend": str(int(row["is_weekend"])),
            "actual_label": int(row[TARGET_COL]),
        })

    client_data = {
        "dataset_summary": summary,
        "metrics": metrics_full,
        "feature_names": feature_names,
        "models_info": {
            "logistic_regression": {
                "name": "Logistic Regression",
                "badge": "Linear Baseline",
                "description": "Linear log-odds probability classifier with inverse frequency class weighting.",
                "best_for": "Screening & Maximum Recall (Catching almost all fraudulent charges)",
            },
            "random_forest": {
                "name": "Random Forest",
                "badge": "Ensemble Bagging",
                "description": "Forest of 40 balanced decision trees voting via majority aggregate.",
                "best_for": "Robustness & Non-linear Interaction Modeling without overfitting",
            },
            "xgboost": {
                "name": "XGBoost",
                "badge": "Gradient Boosted Trees",
                "description": "Sequential boosting minimizing logistic loss with scale-position weights.",
                "best_for": "Highest Precision (22.3%), F1-Score (34.3%), and ROC-AUC (88.2%)",
            },
            "svm": {
                "name": "Support Vector Machine (SVM)",
                "badge": "RBF Maximum Margin",
                "description": "Geometric hyperplane separation in 36-dimensional non-linear feature space.",
                "best_for": "Highest Overall Test Set Accuracy (83.00%)",
            },
        },
        "preprocessor": {
            "num_features": ALL_NUMERICAL_FEATURES,
            "num_medians": [float(x) for x in num_imputer.statistics_],
            "scaler_mean": [float(x) for x in scaler.mean_],
            "scaler_scale": [float(x) for x in scaler.scale_],
            "cat_features": CATEGORICAL_FEATURES,
            "cat_categories": [list(cats) for cats in encoder.categories_],
        },
        "logistic_regression": {
            "coef": [round(float(c), 5) for c in lr_model.coef_[0]],
            "intercept": round(float(lr_model.intercept_[0]), 5),
        },
        "random_forest": {
            "n_estimators": len(rf_model.estimators_),
            "trees": export_rf_trees(rf_model),
        },
        "xgboost": {
            "base_score": 0.5,
            "trees": export_xgb_trees(xgb_model),
        },
        "svm": {
            "gamma": float(svm_model._gamma),
            "intercept": round(float(svm_model.intercept_[0]), 5),
            "dual_coef": [round(float(x), 4) for x in svm_model.dual_coef_[0]],
            "support_vectors": [[round(float(x), 4) for x in row] for row in svm_model.support_vectors_],
            "calibrator": {"a": round(avg_a, 4), "b": round(avg_b, 4)},
        },
        "sample_pool": sample_rows,
    }

    with open(MODEL_DATA_JS_PATH, "w", encoding="utf-8") as f:
        f.write("// Auto-generated client-side multi-model data and weights\n")
        f.write("var MODEL_DATA = ")
        json.dump(client_data, f)
        f.write(";\n")
        f.write("if (typeof window !== 'undefined') { window.MODEL_DATA = MODEL_DATA; }\n")
        f.write("if (typeof global !== 'undefined') { global.MODEL_DATA = MODEL_DATA; }\n")

    print(f"Exported browser multi-model bundle to: {MODEL_DATA_JS_PATH}")
    print("\n" + "=" * 70)
    print("ALL 4 MODELS TRAINED SUCCESSFULLY!")
    print(f"1. Logistic Regression : Acc: {metrics_lr['accuracy']:.4f} | Prec: {metrics_lr['precision']:.4f} | Recall: {metrics_lr['recall']:.4f} | F1: {metrics_lr['f1']:.4f} | AUC: {metrics_lr['roc_auc']:.4f}")
    print(f"2. Random Forest       : Acc: {metrics_rf['accuracy']:.4f} | Prec: {metrics_rf['precision']:.4f} | Recall: {metrics_rf['recall']:.4f} | F1: {metrics_rf['f1']:.4f} | AUC: {metrics_rf['roc_auc']:.4f}")
    print(f"3. XGBoost             : Acc: {metrics_xgb['accuracy']:.4f} | Prec: {metrics_xgb['precision']:.4f} | Recall: {metrics_xgb['recall']:.4f} | F1: {metrics_xgb['f1']:.4f} | AUC: {metrics_xgb['roc_auc']:.4f}")
    print(f"4. SVM (RBF Kernel)    : Acc: {metrics_svm['accuracy']:.4f} | Prec: {metrics_svm['precision']:.4f} | Recall: {metrics_svm['recall']:.4f} | F1: {metrics_svm['f1']:.4f} | AUC: {metrics_svm['roc_auc']:.4f}")
    print("=" * 70)


if __name__ == "__main__":
    train_and_export()
