# Credit Card Fraud Detection — Multi-Model Machine Learning Suite

An end-to-end Machine Learning research system to detect fraudulent transactions using four diverse machine learning architectures:
1. **Random Forest** (Ensemble Bagging)
2. **XGBoost** (Gradient Boosted Decision Trees)
3. **Logistic Regression** (Balanced Linear Baseline)
4. **Support Vector Machine (SVM)** (Non-Linear RBF Kernel Hyperplane)

---

## Highlights of the Multi-Model Architecture

- **Zero Server Setup (No Flask or Backend Needed):** The web interface runs **100% in the browser** via client-side JavaScript. Simply double-click `index.html` in Chrome, Edge, Firefox, or Safari.
- **Model Selection Option While Entering Inputs:** Choose which model to use as the primary evaluation classifier (Random Forest, XGBoost, Logistic Regression, or Support Vector Machine) with clean selector cards.
- **Side-by-Side Compared Results at the Bottom:**
  - **Live Multi-Model Inference Comparison:** Evaluates the transaction simultaneously across all 4 models, displaying predictions, probability bars, decision margins, and consensus indicators.
  - **Holdout Test Set Benchmark Matrix (2,000 Records):** Compares Accuracy, Precision, Recall, F1-Score, ROC-AUC, PR-AUC, False Positives, and False Negatives, highlighting the top-performing model for each metric.
- **Interactive Jupyter Notebook (`credit_card_fraud_detection.ipynb`):** Pre-executed, step-by-step notebook with 9 visualizations, clean markdown walkthroughs, feature importance plots, 4-way confusion matrices, and a viva presentation guide.
- **Single Training Script (`train.py`):** Trains all 4 models, exports serialized `.joblib` artifacts to `models/`, and generates the self-contained `model_data.js` bundle.

---

## Project Structure

```text
ML Assignment/
│
├── credit_card_fraud_detection.ipynb  # Interactive Jupyter Notebook (EDA, 4-model training & 9 visualizations)
├── index.html                         # Interactive Web UI with model selector & compared results
├── style.css                          # Clean, academic light-themed styling
├── app.js                             # Client-side multi-model inference engine (RF, XGB, LR, SVM)
├── model_data.js                      # Preprocessor parameters, weights, decision trees & test samples
├── train.py                           # Clean Python script to retrain all models & export bundle
├── test_credit_card.csv               # Dataset (10,000 unique records)
│
├── models/                            # Serialized scikit-learn & XGBoost models
│   ├── lr_model.joblib                # Trained Logistic Regression model
│   ├── rf_model.joblib                # Trained Random Forest ensemble
│   ├── xgb_model.joblib               # Trained XGBoost classifier
│   ├── svm_model.joblib               # Trained SVM with Platt calibration
│   ├── preprocessing.joblib           # Fitted ColumnTransformer pipeline
│   ├── metrics.json                   # Full comparison metrics across all 4 models
│   └── dataset_summary.json           # Dataset statistics and class distribution
│
├── requirements.txt                   # Minimal Python dependencies (includes xgboost)
└── README.md                          # Project documentation
```

---

## Quick Start Guide

### 1. Open the Interactive Web Application
You do **not** need to start any server or install Flask!
- Simply double-click **`index.html`** or right-click &rarr; *Open with* &rarr; *Google Chrome* / *Microsoft Edge* / *Firefox*.
- Or serve using VS Code Live Server: Right-click `index.html` &rarr; **Open with Live Server**.

#### Using the Web Interface:
1. **Select Primary Model:** Choose between **Random Forest**, **XGBoost**, **Logistic Regression**, or **Support Vector Machine**.
2. **Sample Legitimate:** Loads typical cardholder spending ($45.00 grocery, domestic POS terminal).
3. **Sample Fraud:** Loads a high-risk transaction ($212.01 electronics, midnight, cross-border).
4. **Random Sample:** Randomly selects authentic records from the isolated holdout test dataset.
5. **Evaluate Transaction:** Instantly calculates the prediction for the selected model.
6. **Inspect Compared Results at Bottom:** Scroll down to see the real-time live consensus and the test set benchmark matrix.

---

### 2. View and Run the Jupyter Notebook
Open **`credit_card_fraud_detection.ipynb`** in VS Code or JupyterLab:

```bash
# Install dependencies
pip install -r requirements.txt

# Launch Jupyter
jupyter notebook credit_card_fraud_detection.ipynb
```

The notebook is pre-executed and includes 9 comprehensive visualizations:
1. **Class Distribution (Bar & Pie Charts):** Illustrates the severe ~6% fraud class imbalance.
2. **Transaction Amount Comparison:** Log-scale distributions and boxplots of fraud vs. legit spending.
3. **Fraud by Hour of Day:** Highlights the nocturnal spike in fraud between 12:00 AM and 6:00 AM.
4. **Fraud by Merchant Category & Payment Method:** Shows risk concentrations across sectors.
5. **Correlation Heatmap:** Examines relationships between numerical features and fraud.
6. **Feature Importances (RF vs. XGBoost):** Visualizes which behavioral attributes drive tree splits.
7. **4-Way Confusion Matrices:** Side-by-side comparison of LR, Random Forest, XGBoost, and SVM.
8. **Multi-Model ROC & PR Curves:** Trade-off analysis between True Positive Rate and False Positive Rate.
9. **Performance Metrics Bar Chart:** Compares Accuracy, Precision, Recall, and F1-Score across all 4 models.

---

### 3. Retrain All Models via Terminal (Optional)

```bash
python train.py
```

This single script:
1. Loads and cleans `test_credit_card.csv` (removes duplicates, validates schemas).
2. Performs stratified train/test split (80% train, 20% test).
3. Engineers behavioral fraud risk features (`amount_to_avg_ratio`, `is_night_transaction`, `has_failed_attempts`).
4. Trains all 4 models: Logistic Regression, Random Forest, XGBoost, and SVM with Platt calibration.
5. Evaluates models and saves artifacts into `models/`.
6. Exports `model_data.js` containing full weights, trees, and benchmark matrices for instant browser inference.

---

## Multi-Model Performance Benchmark (Test Set: 2,000 Records)

| Evaluation Metric | Logistic Regression (Baseline) | Random Forest | XGBoost | Support Vector Machine (SVM) | Top Performer / Winner |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Accuracy** | 80.15% | 81.55% | **83.25%** | 83.00% | **XGBoost** (83.25%) |
| **Precision** | 20.34% | 20.98% | **22.92%** | 21.50% | **XGBoost** (22.92%) |
| **Recall** | **79.17%** | 75.00% | 75.83% | 69.17% | **Logistic Regression** (79.17%) |
| **F1-Score** | 32.37% | 32.79% | **35.20%** | 32.81% | **XGBoost** (35.20%) |
| **ROC-AUC** | 87.42% | 86.69% | **88.23%** | 85.62% | **XGBoost** (88.23%) |
| **PR-AUC** | **40.31%** | 36.85% | 38.64% | 29.97% | **Logistic Regression** (40.31%) |
| **False Negatives (Missed)** | **25** | 30 | 29 | 37 | **Logistic Regression** (25 missed) |
| **False Positives (Alarms)** | 372 | 339 | **307** | 303 | **SVM / XGBoost** (Lowest alarms) |

---

## How to Explain These Models (Presentation Guide)

1. **Logistic Regression (High Sensitivity Baseline):**
   - *Why it's used:* Fits a linear log-odds decision boundary. Using `class_weight='balanced'` penalizes false negatives heavily.
   - *Key result:* Catches the most fraudulent transactions (**79.17% Recall**, only 25 missed out of 120). Ideal when missing fraud carries severe penalties.

2. **Random Forest (Robust Ensemble Bagging):**
   - *Why it's used:* Averages 40 decision trees trained on bootstrap feature subsets.
   - *Key result:* Captures non-linear thresholds (e.g. amount spike + nocturnal hour) without overfitting. Delivers balanced **81.55% Accuracy** and **75.00% Recall**.

3. **XGBoost (Top Precision & Overall Performance):**
   - *Why it's used:* Sequentially builds gradient boosted trees, optimizing logistic loss with `scale_pos_weight=15.67`.
   - *Key result:* Achieves the highest Precision (**22.92%**), highest F1-Score (**35.20%**), and highest ROC-AUC (**88.23%**). Minimizes false customer alerts while catching 75.8% of frauds.

4. **Support Vector Machine (RBF Maximum Margin):**
   - *Why it's used:* Maps 36-dimensional feature vectors into an infinite-dimensional Hilbert space via RBF kernel, finding the optimal maximum-margin hyperplane.
   - *Key result:* High overall accuracy (**83.00%**). Probability is calibrated using Platt sigmoid scaling.

---

## Requirements

```text
pandas>=2.0.0
numpy>=1.24.0
scikit-learn>=1.4.0
matplotlib>=3.7.0
seaborn>=0.12.0
joblib>=1.3.0
xgboost>=2.0.0
```
